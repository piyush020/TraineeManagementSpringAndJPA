package com.cg.tms.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.tms.dto.AdminDTO;
import com.cg.tms.dto.TraineeDTO;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService traineeService;
	
	@RequestMapping(value="/ShowWelcomePage")
	public String showWelcomePage(Model model) {
		System.out.println("Hello world");
		return "WelcomePage";
	}
	
	@RequestMapping(value="/ShowLoginPage")
	public String showLoginPage(Model model) {
		System.out.println("Showing welcome page");
		model.addAttribute("admin", new AdminDTO());
		return "Login";
	}
	
	@RequestMapping(value = "/LoginAdmin")
	public String loginAdmin(@ModelAttribute("admin") @Valid AdminDTO admin, BindingResult result, Model model) {
		System.out.println("Login admin");
		if(admin.getUsername().equals("kmv") && admin.getPassword().equals("kmv")) {
			return "WelcomePage";
		}
		model.addAttribute("messageObject", "Please use right password");
		return "Login";
	}
	
	@RequestMapping(value="/ShowRegisterPage")
	public String showRegisterPage(Model model) {
		model.addAttribute("trainee", new TraineeDTO());
		ArrayList<String> traineeDomain = new ArrayList<>();
		traineeDomain.add("JEE");
		traineeDomain.add("Oracle");
		traineeDomain.add("AWS");
		model.addAttribute("trDomain", traineeDomain);
		return "RegisterTrainee";
	}
	
	@RequestMapping(value="/RegisterTrainee")
	public String loginAdmin(@ModelAttribute("trainee") @Valid TraineeDTO trainee, BindingResult result, Model model) {
		traineeService.createTrainee(trainee);
		//TraineeDTO td = traineeService.getTraineeById(trainee.getTraineeId());
		return "RegisterSuccess";
	}
	
}
