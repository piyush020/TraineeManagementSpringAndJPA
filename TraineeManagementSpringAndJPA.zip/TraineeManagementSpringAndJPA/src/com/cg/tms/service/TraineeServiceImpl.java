package com.cg.tms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.dto.TraineeDTO;

@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	private TraineeDao traineeDao;

	public TraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(TraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	public TraineeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public TraineeDTO getTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.getTraineeById(traineeId);
	}

	@Override
	public TraineeDTO createTrainee(TraineeDTO trainee) {
		// TODO Auto-generated method stub
		return traineeDao.createTrainee(trainee);
	}

	@Override
	public ArrayList<TraineeDTO> getAllTrainees() {
		// TODO Auto-generated method stub
		return traineeDao.getAllTrainees();
	}

	@Override
	public TraineeDTO deleteTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.deleteTraineeById(traineeId);
	}

	@Override
	public TraineeDTO updateTrainee(TraineeDTO trainee) {
		// TODO Auto-generated method stub
		return traineeDao.updateTrainee(trainee);
	}
	
	
}
