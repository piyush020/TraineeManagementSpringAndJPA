package com.cg.tms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="trainee_details")
public class TraineeDTO {
	public TraineeDTO() {
		super();
	}

	public TraineeDTO(int traineeId, String traineeName, String traineeDomain, String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "TraineeDTO [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain="
				+ traineeDomain + ", traineeLocation=" + traineeLocation + "]";
	}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Id
	//@GeneratedValue
	@Column(name="trainee_id", length=20)
	private int traineeId;
	
	@Column(name="trainee_name", length=20)
	private String traineeName;
	
	@Column(name="trainee_domain", length=20)
	private String traineeDomain;
	
	@Column(name="trainee_location", length=20)
	private String traineeLocation;
	
}
