package com.cg.tms.dao;

import java.util.ArrayList;

import com.cg.tms.dto.TraineeDTO;

public interface TraineeDao {
	public TraineeDTO getTraineeById(int traineeId);
	public TraineeDTO createTrainee(TraineeDTO trainee);
	public ArrayList<TraineeDTO> getAllTrainees();
	public TraineeDTO deleteTraineeById(int traineeId);
	public TraineeDTO updateTrainee(TraineeDTO trainee);
}
