package com.cg.tms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.tms.dto.TraineeDTO;

@Transactional
@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	EntityManager em;

	public TraineeDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public TraineeDTO getTraineeById(int traineeId) {
		return em.find(TraineeDTO.class, traineeId);
	}

	@Override
	public TraineeDTO createTrainee(TraineeDTO trainee) {
		em.persist(trainee);
		TraineeDTO afterAddition = em.find(TraineeDTO.class, trainee.getTraineeId());
		return afterAddition;
	}

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public ArrayList<TraineeDTO> getAllTrainees() {
		Query query = em.createQuery("SELECT trainees FROM Trainee trainees");
		ArrayList<TraineeDTO> allTrainees = (ArrayList<TraineeDTO>) query.getResultList();
		return allTrainees;
	}

	@Override
	public TraineeDTO deleteTraineeById(int traineeId) {
		TraineeDTO trainee = getTraineeById(traineeId);
		if (trainee != null) {
			em.remove(trainee);
		}
		return trainee;
	}

	@Override
	public TraineeDTO updateTrainee(TraineeDTO trainee) {
		TraineeDTO toBeUpdated = em.find(TraineeDTO.class, trainee.getTraineeId());
		if(toBeUpdated == null) {
			return toBeUpdated;
		}
		toBeUpdated.setTraineeName(trainee.getTraineeName());
		toBeUpdated.setTraineeLocation(trainee.getTraineeLocation());
		toBeUpdated.setTraineeDomain(trainee.getTraineeLocation());
		
		return toBeUpdated;
	}

}
